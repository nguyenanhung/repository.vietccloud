# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui
icon=xbmc.translatePath("special://home/addons/plugin.video.sbtntv/icon.png")
next=xbmc.translatePath("special://home/addons/plugin.video.sbtntv/next.png")
def get_params():
 param=[]
 paramstring=sys.argv[2]
 if len(paramstring)>=2:
  params=sys.argv[2]
  cleanedparams=params.replace('?','')
  if (params[len(params)-1]=='/'):
   params=params[0:len(params)-2]
  pairsofparams=cleanedparams.split('&')
  param={}
  for i in range(len(pairsofparams)):
   splitparams={}
   splitparams=pairsofparams[i].split('=')
   if (len(splitparams))==2:
    param[splitparams[0]]=splitparams[1]
 return param 
def mainMenu():
 addDir("Tin Tức - Bình Luận","http://www.sbtn.tv/vi/chương-trình-sbtn/tin-tức-bình-luận.html",1,icon)
 addDir( "Giải Trí - Đời Sống","http://www.sbtn.tv/vi/chương-trình-sbtn/giải-trí-đời-sống.html",1,icon)  
 addDir("Phóng Sự","http://www.sbtn.tv/vi/phóng-sự.html",2,icon)
 addDir( "SBTN Special","http://www.sbtn.tv/vi/sbtn-special.html",2,icon) 
def addDir(name,url,mode,iconimage):
 u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
 ok=True
 liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
 liz.setInfo( type="Video", infoLabels={ "Title": name } )
 ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
 return ok  
def categories(url):
 link=makeRequest(url)
 if "tin-tức-bình-luận" in url:
  match=re.compile('<li class=".*?leaf"><a href="http://www.sbtn.tv/vi/tin-tức-bình-luận/(.+?)" title="">(.+?)</a></li>').findall(link)
  for url,name in match:
   addDir(name.replace("&amp;", "và"),"http://www.sbtn.tv/vi/tin-tức-bình-luận/"+url,2,icon)
  match=re.compile('<li class=".*?leaf"><a href="http://www.sbtn.tv/vi/tin-tuc-binh-luan/(.+?)" title="">(.+?)</a></li>').findall(link)
  for url,name in match:
   addDir(name.replace("&amp;", "và"),"http://www.sbtn.tv/vi/tin-tuc-binh-luan/"+url,2,icon)                
 else:
  match=re.compile('<li class=".*?leaf"><a href="http://www.sbtn.tv/vi/giải-trí-đời-sống/(.+?)" title="">(.+?)</a></li>').findall(link)
  for url,name in match:
   addDir(name.replace("&amp;", "và"),"http://www.sbtn.tv/vi/giải-trí-đời-sống/"+url,2,icon) 
  match=re.compile('<li class=".*?leaf"><a href="http://www.sbtn.tv/vi/giai-tri-doi-song/(.+?)" title="">(.+?)</a></li>').findall(link)
  for url,name in match:
   addDir(name.replace("&amp;", "và"),"http://www.sbtn.tv/vi/giai-tri-doi-song/"+url,2,icon)                 
def index(url):
 link=makeRequest(url)
 match=re.compile('<a href="(.+?)" rel="tag" title="(.+?)">').findall(link)
 for url,name in match:
  addLink(name.replace("&amp;", "và"),"http://www.sbtn.tv"+url,3,'') 
 match=re.compile('<li class="pager-next"><a title="Đến (.+?)" href="(.+?)">').findall(link)               
 for name,url in match:
  url="http://www.sbtn.tv"+url.replace("&amp;", "&")
  addDir(name.replace("t", "T"),url,2,next)  
def makeRequest(url):
 req=urllib2.Request(url)
 req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
 response=urllib2.urlopen(req)
 link=response.read()
 response.close()  
 return link        
def videoLink(url):
 link=makeRequest(url)
 videoUrl=re.compile('<source src="(.+?)" type="video/mp4" />').findall(link)[0]
 item=xbmcgui.ListItem(name, path=videoUrl)
 xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)  
 return   			
def addLink(name,url,mode,iconimage):
 u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
 ok=True
 liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
 liz.setInfo( type="Video", infoLabels={ "Title": name } )
 liz.setProperty('IsPlayable', 'true')
 ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
 return ok
params=get_params()
url=None
name=None
mode=None
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:mode=int(params["mode"])
except:pass
if mode==1:categories(url)
elif mode==2:index(url)  
elif mode==3:videoLink(url)
else:mainMenu()   
xbmcplugin.endOfDirectory(int(sys.argv[1]))